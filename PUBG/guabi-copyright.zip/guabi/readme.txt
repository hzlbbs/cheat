FAQ
about vcruntime140.dll error
go https://docs.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170
Visual Studio 2015, 2017, 2019, and 2022 select x64 download install


about aimbot
do not use it in rank mode

instructions 
step 1:run start.exe and click start botton before game running

step 2:run yy.exe in match of game(do not run yy.exe in lobby)

step 3: enjoy game