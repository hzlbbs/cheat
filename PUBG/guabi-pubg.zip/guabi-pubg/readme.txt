Current Version:19.1.5.1
Supported OS :: Windows 10
require:Game Mode :: Bordless
Functional:
AIMBOT(removed)
ESP Players
esp Airdrop
custom updates(check OFFsets.ini)

How to start
instructions
step 1:run start.exe and click start botton before game running
step 2:run yy.exe in match of game(do not run yy.exe in lobby)
step 3: enjoy game